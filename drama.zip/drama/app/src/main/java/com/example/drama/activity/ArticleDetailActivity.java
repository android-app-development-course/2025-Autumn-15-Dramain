package com.example.drama.activity;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.R;
import com.example.drama.bean.CommentItem;

import java.util.ArrayList;
import java.util.List;

public class ArticleDetailActivity extends AppCompatActivity {
    private int currentArticleId; // 当前文章的ID（用于关联评论）
    private List<CommentItem> commentList; // 当前文章的评论列表
    private CommentAdapter commentAdapter;
    private EditText etCommentInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_article_detail);

        // 1. 获取当前文章的ID和其他数据
        currentArticleId = getIntent().getIntExtra("article_id", 0);
        String title = getIntent().getStringExtra("article_title");
        String author = getIntent().getStringExtra("article_author");
        int likeCount = getIntent().getIntExtra("article_like", 0);
        int coverResId = getIntent().getIntExtra("article_cover", R.mipmap.ic_launcher);
        String content = getIntent().getStringExtra("article_content");

        // 2. 绑定文章基础数据
        ((ImageView) findViewById(R.id.iv_detail_cover)).setImageResource(coverResId);
        ((TextView) findViewById(R.id.tv_detail_title)).setText(title);
        ((TextView) findViewById(R.id.tv_detail_author)).setText(author);
        ((TextView) findViewById(R.id.tv_detail_like)).setText(String.valueOf(likeCount));
        ((TextView) findViewById(R.id.tv_detail_content)).setText(content);

        // 3. 初始化评论相关控件
        etCommentInput = findViewById(R.id.et_comment_input); // 评论输入框（需给布局中EditText加id）
        RecyclerView rvComments = findViewById(R.id.rv_comments);
        rvComments.setLayoutManager(new LinearLayoutManager(this));

        // 4. 初始化当前文章的评论列表（模拟数据，实际应从数据库/接口获取）
        commentList = getCommentsByArticleId(currentArticleId);
        commentAdapter = new CommentAdapter(this, commentList);
        rvComments.setAdapter(commentAdapter);

        // 5. 返回按钮逻辑
        findViewById(R.id.iv_back).setOnClickListener(v -> finish());

        // 6. 评论发送按钮逻辑
        findViewById(R.id.tv_send_comment).setOnClickListener(v -> sendComment());
    }

    /**
     * 模拟：根据文章ID获取对应的评论列表
     */
    private List<CommentItem> getCommentsByArticleId(int articleId) {
        List<CommentItem> comments = new ArrayList<>();
        // 示例：给当前文章添加初始评论
        if (articleId == 1) { // 假设文章ID=1对应《雷雨》
            comments.add(new CommentItem(1, R.mipmap.tx, "用户A", "写得太深刻了！", "1小时前"));
        } else if (articleId == 2) { // 文章ID=2对应《舞台灯光设计赏析》
            comments.add(new CommentItem(2, R.mipmap.tx, "用户B", "灯光设计的细节分析得很到位！", "2小时前"));
        }
        return comments;
    }

    /**
     * 发送评论：将输入的内容添加到当前文章的评论列表
     */
    private void sendComment() {
        String commentContent = etCommentInput.getText().toString().trim();
        if (TextUtils.isEmpty(commentContent)) {
            Toast.makeText(this, "请输入评论内容", Toast.LENGTH_SHORT).show();
            return;
        }

        // 1. 创建新评论（关联当前文章ID）
        CommentItem newComment = new CommentItem(
                currentArticleId,
                R.mipmap.tx, // 当前登录用户的头像
                "我", // 当前登录用户的昵称
                commentContent,
                "刚刚" // 评论时间
        );

        // 2. 将新评论添加到列表，并更新UI
        commentList.add(0, newComment); // 新增评论放在列表顶部
        commentAdapter.notifyItemInserted(0); // 局部刷新，提升性能

        // 3. 清空输入框
        etCommentInput.setText("");

        // 4. 实际开发中：将新评论保存到数据库/提交到接口
        // saveCommentToDB(newComment);
    }

    // 评论适配器（内部类，保持原有逻辑，适配新增的articleId字段）
    public static class CommentAdapter extends RecyclerView.Adapter<CommentAdapter.CommentViewHolder> {
        private final Context mContext;
        private final List<CommentItem> mCommentList;

        public CommentAdapter(Context context, List<CommentItem> commentList) {
            this.mContext = context;
            this.mCommentList = commentList;
        }

        @NonNull
        @Override
        public CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = View.inflate(mContext, R.layout.item_comment_detail, null);
            return new CommentViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull CommentViewHolder holder, int position) {
            CommentItem item = mCommentList.get(position);
            holder.ivAvatar.setImageResource(item.getAvatarResId());
            holder.tvUserName.setText(item.getUserName());
            holder.tvContent.setText(item.getContent());
            holder.tvTime.setText(item.getTime());
        }

        @Override
        public int getItemCount() {
            return mCommentList.size();
        }

        public static class CommentViewHolder extends RecyclerView.ViewHolder {
            ImageView ivAvatar;
            TextView tvUserName, tvContent, tvTime;

            public CommentViewHolder(@NonNull View itemView) {
                super(itemView);
                ivAvatar = itemView.findViewById(R.id.iv_comment_avatar);
                tvUserName = itemView.findViewById(R.id.tv_comment_user);
                tvContent = itemView.findViewById(R.id.tv_comment_content);
                tvTime = itemView.findViewById(R.id.tv_comment_time);
            }
        }
    }
}