package com.example.drama;

/**
 * 社群列表项的实体类，对应社群页面的每一条群聊数据
 */
public class CommunityItem {
    // 社群ID
    private int id;
    // 社群名称
    private String name;
    // 社群人数
    private String memberCount;
    // 社群最新消息
    private String latestMsg;

    // 构造方法
    public CommunityItem(int id, String name, String memberCount, String latestMsg) {
        this.id = id;
        this.name = name;
        this.memberCount = memberCount;
        this.latestMsg = latestMsg;
    }

    // Getter和Setter方法（必须，Adapter中需要获取数据）
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemberCount() {
        return memberCount;
    }

    public void setMemberCount(String memberCount) {
        this.memberCount = memberCount;
    }

    public String getLatestMsg() {
        return latestMsg;
    }

    public void setLatestMsg(String latestMsg) {
        this.latestMsg = latestMsg;
    }
}