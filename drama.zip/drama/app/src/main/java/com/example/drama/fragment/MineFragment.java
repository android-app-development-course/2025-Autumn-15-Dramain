package com.example.drama.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;

import com.example.drama.R;

public class MineFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_mine, container, false);

        // 可在这里添加点击事件（如“管理”“查看更多”“设置”等）
        rootView.findViewById(R.id.tv_create_manage).setOnClickListener(v -> {
            // 我的创作管理逻辑
        });
        rootView.findViewById(R.id.tv_collect_more).setOnClickListener(v -> {
            // 我的收藏查看更多逻辑
        });
        rootView.findViewById(R.id.iv_setting).setOnClickListener(v -> {
            // 设置页面跳转逻辑
        });

        return rootView;
    }
}