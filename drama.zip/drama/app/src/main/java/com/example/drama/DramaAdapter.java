package com.example.drama;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.activity.DramaDetailActivity;
import com.example.drama.bean.RecentDrama;

import java.util.List;

/**
 * 近期演出列表适配器（适配RecentDrama实体类）
 */
public class DramaAdapter extends RecyclerView.Adapter<DramaAdapter.DramaViewHolder> {
    private Context mContext;
    private List<RecentDrama> mRecentDramaList;

    // 构造方法：接收上下文和RecentDrama列表
    public DramaAdapter(Context context, List<RecentDrama> recentDramaList) {
        this.mContext = context;
        this.mRecentDramaList = recentDramaList;
    }

    @NonNull
    @Override
    public DramaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 加载列表项布局（item_recent_drama.xml）
        View view = LayoutInflater.from(mContext)
                .inflate(R.layout.item_recent_drama, parent, false);
        return new DramaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DramaViewHolder holder, int position) {
        // 获取当前位置的RecentDrama数据
        RecentDrama drama = mRecentDramaList.get(position);

        // 绑定数据到列表项UI
        holder.ivCover.setImageResource(drama.getCoverResId());
        holder.tvName.setText(drama.getName());
        holder.tvVenueTime.setText(drama.getVenue() + " · " + drama.getTime());
        holder.tvType.setText(drama.getType());
        holder.tvTicketStatus.setText(drama.getTicketStatus());

        // 核心：点击列表项跳转到剧目详情页
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(mContext, DramaDetailActivity.class);
            // 传递RecentDrama的所有字段到详情页
            intent.putExtra("drama_cover", drama.getCoverResId());
            intent.putExtra("drama_name", drama.getName());
            intent.putExtra("drama_time", drama.getTime());
            intent.putExtra("drama_venue", drama.getVenue());
            intent.putExtra("drama_type", drama.getType());
            intent.putExtra("drama_ticket", drama.getTicketStatus());
            intent.putExtra("drama_detail", drama.getDetail());
            mContext.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return mRecentDramaList == null ? 0 : mRecentDramaList.size();
    }

    // ViewHolder：缓存列表项控件
    public static class DramaViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCover;
        TextView tvName, tvVenueTime, tvType, tvTicketStatus;

        public DramaViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCover = itemView.findViewById(R.id.iv_drama_cover);
            tvName = itemView.findViewById(R.id.tv_drama_name);
            tvVenueTime = itemView.findViewById(R.id.tv_drama_venue_time);
            tvType = itemView.findViewById(R.id.tv_drama_type);
            tvTicketStatus = itemView.findViewById(R.id.tv_drama_ticket);
        }
    }
}