package com.example.drama.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.drama.FilterActivity;
import com.example.drama.activity.SearchActivity;
import com.example.drama.bean.HotDrama;
import com.example.drama.HotDramaAdapter;
import com.example.drama.R;
import com.example.drama.bean.RecentDrama;
import com.example.drama.RecentDramaAdapter;
import com.example.drama.RecommendDrama;
import com.example.drama.RecommendDramaAdapter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DramaFragment extends Fragment {
    private ViewPager2 vpHotDrama;
    private RecyclerView rvRecentDrama, rvRecommendDrama;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_drama, container, false);

        // 初始化控件
        vpHotDrama = rootView.findViewById(R.id.vp_hot_drama);
        rvRecentDrama = rootView.findViewById(R.id.rv_recent_drama);
        rvRecommendDrama = rootView.findViewById(R.id.rv_recommend_drama);

        // 1. 热门剧目轮播
        initHotDrama();
        // 2. 近期演出列表
        initRecentDrama();
        // 3. 猜你喜欢列表
        initRecommendDrama();
        ImageView ivFilter = rootView.findViewById(R.id.iv_filter); // 筛选图标
        ivFilter.setOnClickListener(v -> {
            // 跳转到筛选Activity
            Intent intent = new Intent(getContext(), FilterActivity.class);
            startActivity(intent);
        });
        EditText etSearch = rootView.findViewById(R.id.et_search);
        etSearch.setOnClickListener(v -> {
            Intent intent = new Intent(getContext(), SearchActivity.class);
            startActivity(intent);
        });
        return rootView;
    }

    // 初始化热门剧目轮播
    private void initHotDrama() {
        List<HotDrama> hotList = new ArrayList<>();
        hotList.add(new HotDrama(R.mipmap.cg, "茶馆", "北京人民艺术剧院"));
        hotList.add(new HotDrama(R.mipmap.mao, "猫", "安德鲁·洛伊德·韦伯剧团"));
        vpHotDrama.setAdapter(new HotDramaAdapter(hotList));
    }

    // 初始化近期演出
    private void initRecentDrama() {
        List<RecentDrama> recentList = new ArrayList<>();
        recentList.add(new RecentDrama(R.mipmap.al, "暗恋桃花源", "11月15日", "北京保利剧院", "话剧", "余票紧张","《暗恋桃花源》是赖声川的经典话剧，讲述了“暗恋”与“桃花源”两个剧组因场地冲突同台演出的荒诞故事，融合悲剧与喜剧，探讨爱情与理想的永恒主题，是华语话剧的里程碑之作。"));
        recentList.add(new RecentDrama(R.mipmap.mzt, "摇滚莫扎特", "11月17日", "上海文化广场", "音乐剧", "少量余票","《摇滚莫扎特》以摇滚曲风重新演绎莫扎特的传奇一生，融合古典音乐与现代摇滚，舞台华丽、歌曲热血，完美展现了天才音乐家的激情、叛逆与短暂而璀璨的人生。"));
        recentList.add(new RecentDrama(R.mipmap.te, "天鹅湖", "11月20日", "国家大剧院", "舞剧", "可售","《天鹅湖》是柴可夫斯基创作的经典芭蕾舞剧，讲述公主奥洁塔被魔法变成天鹅，王子齐格菲尔德通过真爱破除诅咒的故事，舞美与音乐堪称芭蕾舞剧的巅峰之作。"));
        rvRecentDrama.setLayoutManager(new LinearLayoutManager(getContext()));
        rvRecentDrama.setAdapter(new RecentDramaAdapter( getContext(),recentList));
    }

    // 初始化猜你喜欢
    private void initRecommendDrama() {
        List<RecommendDrama> recommendList = new ArrayList<>();
        recommendList.add(new RecommendDrama(
                R.mipmap.lyu, "雷雨", "北京人民艺术剧院",
                Arrays.asList("话剧", "悲剧", "经典"),
                "通过一个封建家庭的悲剧，反映了中国20世纪初的社会现实与人性冲突。"

        ));
        recommendList.add(new RecommendDrama(
                R.mipmap.je, "吉赛尔", "巴黎歌剧院芭蕾舞团",
                Arrays.asList("舞剧", "浪漫主义", "经典"),
                "讲述农村少女吉赛尔因爱情背叛心碎而死，化为幽灵后依然守护真爱的悲情故事。"
        ));
        rvRecommendDrama.setLayoutManager(new LinearLayoutManager(getContext()));
        rvRecommendDrama.setAdapter(new RecommendDramaAdapter(getContext(), recommendList));
    }
}