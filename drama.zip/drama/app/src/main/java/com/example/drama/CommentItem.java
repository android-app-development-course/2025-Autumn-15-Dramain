package com.example.drama;

/**
 * 评论和@消息的实体类
 */
public class CommentItem {
    private int avatarResId; // 评论/@用户的头像资源ID
    private String userName; // 用户名
    private String content;  // 评论/@内容
    private String time;     // 时间

    // 构造方法
    public CommentItem(int avatarResId, String userName, String content, String time) {
        this.avatarResId = avatarResId;
        this.userName = userName;
        this.content = content;
        this.time = time;
    }

    // Getter方法（供适配器调用）
    public int getAvatarResId() { return avatarResId; }
    public String getUserName() { return userName; }
    public String getContent() { return content; }
    public String getTime() { return time; }
}