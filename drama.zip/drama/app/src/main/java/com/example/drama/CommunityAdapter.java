package com.example.drama;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * 社群列表的RecyclerView适配器
 */
public class CommunityAdapter extends RecyclerView.Adapter<CommunityAdapter.CommunityViewHolder> {

    // 上下文
    private Context mContext;
    // 社群数据列表
    private List<CommunityItem> mCommunityList;

    // 构造方法
    public CommunityAdapter(Context context, List<CommunityItem> communityList) {
        this.mContext = context;
        this.mCommunityList = communityList;
    }

    // 创建ViewHolder（加载列表项布局）
    @NonNull
    @Override
    public CommunityViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_community, parent, false);
        return new CommunityViewHolder(view);
    }

    // 绑定数据到ViewHolder
    @Override
    public void onBindViewHolder(@NonNull CommunityViewHolder holder, int position) {
        CommunityItem item = mCommunityList.get(position);
        holder.tvCommunityName.setText(item.getName());
        holder.tvMemberCount.setText(item.getMemberCount());
        holder.tvLatestMsg.setText(item.getLatestMsg());

        // 【扩展点】添加列表项点击事件
        holder.itemView.setOnClickListener(v -> {
            // 后续可实现跳转到社群详情页
        });
    }

    // 获取列表项数量
    @Override
    public int getItemCount() {
        return mCommunityList == null ? 0 : mCommunityList.size();
    }

    // ViewHolder：缓存列表项的控件，提升性能
    public static class CommunityViewHolder extends RecyclerView.ViewHolder {
        TextView tvCommunityName;  // 社群名称
        TextView tvMemberCount;    // 社群人数
        TextView tvLatestMsg;      // 最新消息

        public CommunityViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCommunityName = itemView.findViewById(R.id.tv_community_name);
            tvMemberCount = itemView.findViewById(R.id.tv_member_count);
            tvLatestMsg = itemView.findViewById(R.id.tv_latest_msg);
        }
    }
}