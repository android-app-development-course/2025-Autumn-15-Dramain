package com.example.drama.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.bean.HomeArticle;
import com.example.drama.HomeArticleAdapter;
import com.example.drama.R;
import com.google.android.material.tabs.TabLayout;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private TabLayout tabLayout;
    private RecyclerView rvArticles;
    private HomeArticleAdapter articleAdapter;
    private List<HomeArticle> articleList;

    public HomeFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);
        
        // 初始化控件
        tabLayout = rootView.findViewById(R.id.tab_layout);
        rvArticles = rootView.findViewById(R.id.rv_home_articles);
        
        // 1. 初始化顶部标签
        initTabs();
        
        // 2. 初始化文章列表（模拟数据）
        initArticleList();
        
        // 3. 初始化RecyclerView（网格布局，2列）
        rvArticles.setLayoutManager(new GridLayoutManager(getContext(), 2));
        articleAdapter = new HomeArticleAdapter(getContext(), articleList);
        rvArticles.setAdapter(articleAdapter);
        
        // 标签切换事件（可根据标签加载不同数据）
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // 切换标签时，加载对应分类的文章（示例：仅刷新模拟数据）
                initArticleList();
                articleAdapter.notifyDataSetChanged();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
        
        return rootView;
    }

    // 初始化顶部标签
    private void initTabs() {
        tabLayout.addTab(tabLayout.newTab().setText("关注"));
        tabLayout.addTab(tabLayout.newTab().setText("推荐"));
        tabLayout.addTab(tabLayout.newTab().setText("Repo"));
        tabLayout.addTab(tabLayout.newTab().setText("同人"));
        tabLayout.addTab(tabLayout.newTab().setText("返场"));
        // 默认选中“推荐”
        tabLayout.getTabAt(1).select();
    }

    // 初始化文章列表（模拟数据，后续替换为SQLite/网络请求）
    private void initArticleList() {
        articleList = new ArrayList<>();

            articleList = new ArrayList<>();
            // 修复：传入int类型的资源ID
            articleList.add(new HomeArticle(1, R.mipmap.tx, "《雷雨》观后随笔", "戏剧爱好者", 128, R.mipmap.lyu," \"《雷雨》是曹禺先生的经典之作，整部剧以周家的家庭悲剧为核心，揭露了旧中国上层社会的腐朽与黑暗。周朴园的伪善、繁漪的反抗、四凤的单纯，每个人物都被时代裹挟，最终走向毁灭。"));
            articleList.add(new HomeArticle(2, R.mipmap.tx, "舞台灯光设计赏析", "舞台设计师", 156, R.mipmap.wt,"舞台灯光设计是艺术与设计intersection的典型案例，在电影、戏剧、动画等艺术作品中，灯光设计是 crucial factor，也是 crucial factor。"));
            articleList.add(new HomeArticle(3, R.mipmap.tx, "舞台设计解读：《茶馆》", "话剧评论家", 89, R.mipmap.cg,"《茶馆》是老舍的代表作，是老舍对茶馆的解读，是老舍对茶馆的解读，是老舍对茶馆的解读，是老舍对茶馆的解读，是老舍对茶馆的解读，是老舍对茶馆的解读，是老舍对茶馆的解读，是老舍对茶馆的解读，是老舍对"));
            articleList.add(new HomeArticle(4, R.mipmap.tx, "哈姆雷特独白解析", "莎剧研究者", 203, R.mipmap.hmlt,"哈姆雷特独白解析，哈姆雷特独白解析，哈姆雷特独白解析，哈姆雷特独白解析，哈姆雷特独白解析，哈姆雷特独白解析，哈姆雷特独白解析，哈姆雷特独白解析，哈姆雷特独白解析，哈姆雷特独白解析，哈姆雷特独白解析，哈姆雷特独"));
            articleList.add(new HomeArticle(5, R.mipmap.tx, "当代戏剧创作趋势", "戏剧编剧", 167, R.mipmap.xj,"当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作趋势，当代戏剧创作"));

    }
}