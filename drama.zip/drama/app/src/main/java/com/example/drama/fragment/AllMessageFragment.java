package com.example.drama.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.GroupAdapter;
import com.example.drama.bean.GroupItem;
import com.example.drama.MessageAdapter;
import com.example.drama.MessageItem;
import com.example.drama.R;

import java.util.ArrayList;
import java.util.List;

public class AllMessageFragment extends Fragment {
    private RecyclerView rvAllMsg, rvRecommendGroup;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_all_message, container, false);
        rvAllMsg = rootView.findViewById(R.id.rv_all_msg);
        rvRecommendGroup = rootView.findViewById(R.id.rv_recommend_group);

        // 初始化消息列表
        initMessageList();
        // 初始化推荐剧组
        initRecommendGroup();

        return rootView;
    }

    // 初始化消息列表
    private void initMessageList() {
        List<MessageItem> msgList = new ArrayList<>();
        msgList.add(new MessageItem(R.mipmap.lyu, "《雷雨》爱好者交流群", "周朴园的角色分析很到位，我补充一点...", "10:23", 5));
        msgList.add(new MessageItem(R.drawable.lm, "李明", "你上周分享的《茶馆》解析写得真好！", "09:45", 1));
        msgList.add(new MessageItem(R.mipmap.hj, "话剧表演技巧分享", "下周六的线下workshop报名已截止", "昨天", 3));
        msgList.add(new MessageItem(R.mipmap.zd, "张导演", "关于你提的改编想法，我们可以约时间聊聊", "周三", 0));

        rvAllMsg.setLayoutManager(new LinearLayoutManager(getContext()));
        rvAllMsg.setAdapter(new MessageAdapter(getContext(), msgList));
    }

    // 初始化推荐剧组
    private void initRecommendGroup() {
        List<GroupItem> groupList = new ArrayList<>();
        groupList.add(new GroupItem(R.mipmap.sb, "莎士比亚戏剧研究组", "解读莎翁名剧，分析角色塑造与语言艺术", "312人"));
        groupList.add(new GroupItem(R.mipmap.cg, "《茶馆》舞台艺术剧组", "聚焦老舍作品，分析舞台设计与表演技巧", "187人"));
        groupList.add(new GroupItem(R.mipmap.xf, "先锋戏剧创作组", "探索实验戏剧形式，融合多元艺术表达", "423人"));

        rvRecommendGroup.setLayoutManager(new LinearLayoutManager(getContext()));
        rvRecommendGroup.setAdapter(new GroupAdapter(getContext(), groupList));
    }
}