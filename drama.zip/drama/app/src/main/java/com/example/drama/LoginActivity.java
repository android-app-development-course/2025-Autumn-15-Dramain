package com.example.drama;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText etPassword;
    private ImageView ivPwdEye;
    private boolean isPwdVisible = false; // 密码是否可见

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 初始化控件
        etPassword = findViewById(R.id.et_password);
        ivPwdEye = findViewById(R.id.iv_pwd_eye);

        // 密码显示/隐藏按钮点击事件
        ivPwdEye.setOnClickListener(v -> {
            if (isPwdVisible) {
                // 隐藏密码
                etPassword.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
                ivPwdEye.setImageResource(R.drawable.ic_eye_close);
            } else {
                // 显示密码
                etPassword.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                ivPwdEye.setImageResource(R.drawable.ic_eyes);
            }
            isPwdVisible = !isPwdVisible;
            // 保持光标在末尾
            etPassword.setSelection(etPassword.getText().length());
        });

        // 登录按钮点击事件
        findViewById(R.id.btn_login).setOnClickListener(v -> {
            String phone = ((EditText) findViewById(R.id.et_phone)).getText().toString();
            String password = etPassword.getText().toString();
            if (!phone.isEmpty() && !password.isEmpty()) {
                Intent intent = new Intent(LoginActivity.this, WelcomeActivity.class);
                startActivity(intent);
                finish(); // 关闭登录页
            }
        });

        // 注册/忘记密码点击事件
        findViewById(R.id.tv_register).setOnClickListener(v -> {
            // 跳转到注册页面
        });
        findViewById(R.id.tv_forget_pwd).setOnClickListener(v -> {
            // 跳转到忘记密码页面
        });
    }
}