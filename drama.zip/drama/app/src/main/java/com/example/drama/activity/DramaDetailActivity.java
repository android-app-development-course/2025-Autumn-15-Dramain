package com.example.drama.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.drama.R;

/**
 * 剧目详情页（完全适配RecentDrama实体类）
 */
public class DramaDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drama_detail);

        // 1. 接收从DramaAdapter传递的RecentDrama数据
        int coverResId = getIntent().getIntExtra("drama_cover", R.mipmap.ic_launcher);
        String dramaName = getIntent().getStringExtra("drama_name");
        String dramaTime = getIntent().getStringExtra("drama_time");
        String dramaVenue = getIntent().getStringExtra("drama_venue");
        String dramaType = getIntent().getStringExtra("drama_type");
        String dramaTicket = getIntent().getStringExtra("drama_ticket");
        String dramaDetail = getIntent().getStringExtra("drama_detail");

        // 2. 绑定数据到UI控件
        // 封面图
        ImageView ivCover = findViewById(R.id.iv_detail_cover);
        ivCover.setImageResource(coverResId);
        // 剧目名称
        TextView tvName = findViewById(R.id.tv_detail_name);
        tvName.setText(dramaName);
        // 剧目类型
        TextView tvType = findViewById(R.id.tv_detail_type);
        tvType.setText(dramaType);
        // 票务状态
        TextView tvTicket = findViewById(R.id.tv_detail_ticket);
        tvTicket.setText(dramaTicket);
        // 演出时间
        TextView tvTime = findViewById(R.id.tv_detail_time);
        tvTime.setText(dramaTime);
        // 演出场馆
        TextView tvVenue = findViewById(R.id.tv_detail_venue);
        tvVenue.setText(dramaVenue);
        // 剧目详情内容
        TextView tvContent = findViewById(R.id.tv_detail_content);
        tvContent.setText(dramaDetail);

        // 3. 返回按钮点击事件：关闭详情页，返回DramaFragment
        ImageView ivBack = findViewById(R.id.iv_back);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // 销毁当前Activity，回到上一级页面
            }
        });

        // 4. 立即购票按钮点击事件（模拟购票逻辑）
        TextView tvBuyTicket = findViewById(R.id.tv_buy_ticket); // 需给布局中购票按钮加id: tv_buy_ticket
        tvBuyTicket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(DramaDetailActivity.this, "跳转到购票页面：" + dramaName, Toast.LENGTH_SHORT).show();
                // 实际开发中：可跳转到购票Activity，传递剧目ID/名称等信息
            }
        });
    }
}