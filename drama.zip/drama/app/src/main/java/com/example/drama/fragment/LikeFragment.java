package com.example.drama.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.LikeAdapter;
import com.example.drama.bean.LikeItem;
import com.example.drama.R;

import java.util.ArrayList;
import java.util.List;

public class LikeFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_like, container, false);
        RecyclerView rvLike = rootView.findViewById(R.id.rv_like);

        List<LikeItem> likeList = new ArrayList<>();
        likeList.add(new LikeItem(R.mipmap.jm, "王戏剧迷", "赞了你的《哈姆雷特》角色分析", "10:15"));
        likeList.add(new LikeItem(R.mipmap.ld, "李编剧", "收藏了你的原创剧本《城市光影》", "昨天"));
        likeList.add(new LikeItem(R.mipmap.zjs, "张教授", "赞了你的戏剧理论分享", "昨天"));

        rvLike.setLayoutManager(new LinearLayoutManager(getContext()));
        rvLike.setAdapter(new LikeAdapter(getContext(), likeList));
        return rootView;
    }
}