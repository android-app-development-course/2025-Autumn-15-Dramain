package com.example.drama;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MsgViewHolder> {
    private Context mContext;
    private List<MessageItem> mMsgList;

    public MessageAdapter(Context context, List<MessageItem> msgList) {
        this.mContext = context;
        this.mMsgList = msgList;
    }

    @NonNull
    @Override
    public MsgViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_message, parent, false);
        return new MsgViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MsgViewHolder holder, int position) {
        MessageItem item = mMsgList.get(position);
        holder.ivAvatar.setImageResource(item.getAvatarResId());
        holder.tvTitle.setText(item.getTitle());
        holder.tvContent.setText(item.getContent());
        holder.tvTime.setText(item.getTime());

        // 未读数量（0则隐藏）
        if (item.getUnreadCount() > 0) {
            holder.tvUnread.setVisibility(View.VISIBLE);
            holder.tvUnread.setText(String.valueOf(item.getUnreadCount()));
        } else {
            holder.tvUnread.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return mMsgList.size();
    }

    public static class MsgViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAvatar;
        TextView tvTitle, tvContent, tvTime, tvUnread;

        public MsgViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.iv_msg_avatar);
            tvTitle = itemView.findViewById(R.id.tv_msg_title);
            tvContent = itemView.findViewById(R.id.tv_msg_content);
            tvTime = itemView.findViewById(R.id.tv_msg_time);
            tvUnread = itemView.findViewById(R.id.tv_msg_unread);
        }
    }
}