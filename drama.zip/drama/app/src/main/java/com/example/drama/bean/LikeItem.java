package com.example.drama.bean;

/**
 * 赞和收藏消息的实体类
 */
public class LikeItem {
    private int avatarResId; // 操作用户的头像资源ID
    private String userName; // 用户名
    private String action;   // 操作内容（赞/收藏+对应内容）
    private String time;     // 操作时间

    // 构造方法
    public LikeItem(int avatarResId, String userName, String action, String time) {
        this.avatarResId = avatarResId;
        this.userName = userName;
        this.action = action;
        this.time = time;
    }

    // Getter方法（供适配器调用）
    public int getAvatarResId() { return avatarResId; }
    public String getUserName() { return userName; }
    public String getAction() { return action; }
    public String getTime() { return time; }
}