package com.example.drama;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DramaDBHelper extends SQLiteOpenHelper {
    // 数据库名 + 版本
    private static final String DB_NAME = "drama_db";
    private static final int DB_VERSION = 1;

    // 剧目表（示例）
    public static final String TABLE_DRAMA = "drama";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_NAME = "name"; // 剧目名
    public static final String COLUMN_TYPE = "type"; // 类型（音乐剧/话剧等）
    public static final String COLUMN_ACTOR = "actor"; // 演员
    public static final String COLUMN_TIME = "time"; // 演出时间

    // 创建剧目表的SQL语句
    private static final String CREATE_TABLE_DRAMA = "CREATE TABLE " + TABLE_DRAMA + " (" +
            COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
            COLUMN_NAME + " TEXT NOT NULL, " +
            COLUMN_TYPE + " TEXT, " +
            COLUMN_ACTOR + " TEXT, " +
            COLUMN_TIME + " TEXT)";

    public DramaDBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_DRAMA); // 创建剧目表
        // 可添加用户表、收藏表等
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DRAMA);
        onCreate(db);
    }
}