package com.example.drama;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.activity.RecommendDramaDetailActivity;

import java.util.List;

public class RecommendDramaAdapter extends RecyclerView.Adapter<RecommendDramaAdapter.RecommendViewHolder> {
    private Context mContext;
    private List<RecommendDrama> mRecommendList;

    // 构造方法1：带Context（推荐）
    public RecommendDramaAdapter(Context context, List<RecommendDrama> recommendList) {
        this.mContext = context;
        this.mRecommendList = recommendList;
    }

    // 构造方法2：兼容你的原有代码
    public RecommendDramaAdapter(List<RecommendDrama> recommendList) {
        this.mRecommendList = recommendList;
    }

    @NonNull
    @Override
    public RecommendViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 初始化Context（如果构造方法没传）
        if (mContext == null) {
            mContext = parent.getContext();
        }
        // 关键：确保加载的是正确的布局文件（item_recommend_drama.xml）
        View view = LayoutInflater.from(mContext)
                .inflate(R.layout.item_recommend_drama, parent, false);
        return new RecommendViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecommendViewHolder holder, int position) {
        // 空指针保护：先检查列表和数据是否为空
        if (mRecommendList == null || mRecommendList.size() == 0 || position >= mRecommendList.size()) {
            return;
        }

        RecommendDrama drama = mRecommendList.get(position);
        
        // 1. 绑定封面图（避免空资源ID）
        if (drama.getCoverResId() != 0) {
            holder.ivCover.setImageResource(drama.getCoverResId());
        }

        // 2. 绑定名称（非空判断）
        if (drama.getName() != null) {
            holder.tvName.setText(drama.getName()); // 第66行对应的位置，确保tvName不为null
        }

        // 3. 绑定剧团
//        if (drama.getGroup() != null) {
//            holder.tvGroup.setText(drama.getGroup());
//        }

        // 4. 拼接标签
        if (drama.getTags() != null && !drama.getTags().isEmpty()) {
            StringBuilder tagStr = new StringBuilder();
            for (int i = 0; i < drama.getTags().size(); i++) {
                tagStr.append(drama.getTags().get(i));
                if (i < drama.getTags().size() - 1) {
                    tagStr.append(" | ");
                }
            }
            holder.tvTags.setText(tagStr.toString());
        }

        // 5. 绑定简介
        if (drama.getDesc() != null) {
            holder.tvDesc.setText(drama.getDesc());
        }

        // 6. 点击跳转（空指针保护）
        holder.itemView.setOnClickListener(v -> {
            if (mContext == null) return;
            Intent intent = new Intent(mContext, RecommendDramaDetailActivity.class);
            intent.putExtra("recommend_cover", drama.getCoverResId());
            intent.putExtra("recommend_name", drama.getName());
//            intent.putExtra("recommend_group", drama.getGroup());
            intent.putExtra("recommend_tags", drama.getTags() != null ? String.join(",", drama.getTags()) : "");
            intent.putExtra("recommend_desc", drama.getDesc());
            mContext.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return mRecommendList == null ? 0 : mRecommendList.size();
    }

    // ViewHolder：确保控件ID与布局完全一致
    public static class RecommendViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCover;       // 对应iv_recommend_cover
        TextView tvName;         // 对应tv_recommend_name
        TextView tvGroup;        // 对应tv_recommend_group
        TextView tvTags;         // 对应tv_recommend_tags
        TextView tvDesc;         // 对应tv_recommend_desc

        public RecommendViewHolder(@NonNull View itemView) {
            super(itemView);
            // 关键：findViewById的ID必须与布局中完全一致
            ivCover = itemView.findViewById(R.id.iv_recommend_cover);
            tvName = itemView.findViewById(R.id.tv_recommend_name);
            tvGroup = itemView.findViewById(R.id.tv_recommend_group);
            tvTags = itemView.findViewById(R.id.tv_recommend_tags);
            tvDesc = itemView.findViewById(R.id.tv_recommend_desc);
        }
    }
}