package com.example.drama.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.example.drama.R;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import java.util.ArrayList;
import java.util.List;

public class CommunityFragment extends Fragment {
    private TabLayout tabLayout;
    private ViewPager2 vpCommunity;
    private List<String> tabTitles = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_community, container, false);
        tabLayout = rootView.findViewById(R.id.tab_layout);
        vpCommunity = rootView.findViewById(R.id.vp_community);

        // 初始化标签标题
        tabTitles.add("全部");
        tabTitles.add("赞和收藏");
        tabTitles.add("新增粉丝");
        tabTitles.add("评论和@");

        // 设置ViewPager2适配器
        vpCommunity.setAdapter(new FragmentStateAdapter(this) {
            @Override
            public Fragment createFragment(int position) {
                // 根据标签位置返回对应Fragment
                switch (position) {
                    case 0: return new AllMessageFragment(); // 全部消息
                    case 1: return new LikeFragment();       // 赞和收藏
                    case 2: return new NewFanFragment();     // 新增粉丝
                    case 3: return new CommentFragment();    // 评论和@
                    default: return new AllMessageFragment();
                }
            }

            @Override
            public int getItemCount() {
                return tabTitles.size();
            }
        });

        // 关联TabLayout和ViewPager2
        new TabLayoutMediator(tabLayout, vpCommunity, (tab, position) -> {
            tab.setText(tabTitles.get(position));
        }).attach();

        return rootView;
    }
}