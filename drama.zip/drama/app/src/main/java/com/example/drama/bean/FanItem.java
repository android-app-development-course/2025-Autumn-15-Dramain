package com.example.drama.bean;

/**
 * 新增粉丝消息的实体类
 */
public class FanItem {
    private int avatarResId; // 粉丝头像资源ID
    private String userName; // 粉丝用户名
    private String desc;     // 粉丝简介/备注
    private String time;     // 关注时间

    // 构造方法
    public FanItem(int avatarResId, String userName, String desc, String time) {
        this.avatarResId = avatarResId;
        this.userName = userName;
        this.desc = desc;
        this.time = time;
    }

    // Getter方法（供适配器调用）
    public int getAvatarResId() { return avatarResId; }
    public String getUserName() { return userName; }
    public String getDesc() { return desc; }
    public String getTime() { return time; }
}