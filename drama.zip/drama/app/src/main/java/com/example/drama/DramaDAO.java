package com.example.drama;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.drama.bean.Drama;

import java.util.ArrayList;
import java.util.List;

public class DramaDAO {
    private SQLiteDatabase db;
    private DramaDBHelper dbHelper;

    public DramaDAO(Context context) {
        dbHelper = new DramaDBHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    // 新增剧目
    public long addDrama(Drama drama) {
        ContentValues values = new ContentValues();
        values.put(DramaDBHelper.COLUMN_NAME, drama.getName());
        values.put(DramaDBHelper.COLUMN_TYPE, drama.getType());
        values.put(DramaDBHelper.COLUMN_ACTOR, drama.getActor());
        values.put(DramaDBHelper.COLUMN_TIME, drama.getTime());
        return db.insert(DramaDBHelper.TABLE_DRAMA, null, values);
    }

    // 查询所有剧目
    public List<Drama> getAllDramas() {
        List<Drama> dramaList = new ArrayList<>();
        Cursor cursor = db.query(DramaDBHelper.TABLE_DRAMA, null, null, null, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                Drama drama = new Drama();
                drama.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DramaDBHelper.COLUMN_ID)));
                drama.setName(cursor.getString(cursor.getColumnIndexOrThrow(DramaDBHelper.COLUMN_NAME)));
                drama.setType(cursor.getString(cursor.getColumnIndexOrThrow(DramaDBHelper.COLUMN_TYPE)));
                drama.setActor(cursor.getString(cursor.getColumnIndexOrThrow(DramaDBHelper.COLUMN_ACTOR)));
                drama.setTime(cursor.getString(cursor.getColumnIndexOrThrow(DramaDBHelper.COLUMN_TIME)));
                dramaList.add(drama);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return dramaList;
    }


}