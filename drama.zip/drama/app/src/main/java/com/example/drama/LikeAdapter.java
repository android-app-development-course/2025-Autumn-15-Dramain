package com.example.drama;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.bean.LikeItem;

import java.util.List;

/**
 * 赞和收藏消息列表的适配器
 */
public class LikeAdapter extends RecyclerView.Adapter<LikeAdapter.LikeViewHolder> {
    private Context mContext;
    private List<LikeItem> mLikeList;

    // 构造方法
    public LikeAdapter(Context context, List<LikeItem> likeList) {
        this.mContext = context;
        this.mLikeList = likeList;
    }

    @NonNull
    @Override
    public LikeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 加载赞和收藏列表项布局
        View view = LayoutInflater.from(mContext)
                .inflate(R.layout.item_like, parent, false);
        return new LikeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LikeViewHolder holder, int position) {
        // 绑定数据到控件
        LikeItem item = mLikeList.get(position);
        holder.ivAvatar.setImageResource(item.getAvatarResId());
        holder.tvUserName.setText(item.getUserName());
        holder.tvAction.setText(item.getAction());
        holder.tvTime.setText(item.getTime());
    }

    @Override
    public int getItemCount() {
        return mLikeList == null ? 0 : mLikeList.size();
    }

    // ViewHolder：缓存列表项控件
    public static class LikeViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAvatar;
        TextView tvUserName, tvAction, tvTime;

        public LikeViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.iv_like_avatar);
            tvUserName = itemView.findViewById(R.id.tv_like_name);
            tvAction = itemView.findViewById(R.id.tv_like_action);
            tvTime = itemView.findViewById(R.id.tv_like_time);
        }
    }
}