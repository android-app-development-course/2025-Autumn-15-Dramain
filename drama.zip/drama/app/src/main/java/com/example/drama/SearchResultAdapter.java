package com.example.drama;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.activity.DramaDetailActivity;
import com.example.drama.bean.SearchItem;

import java.util.List;

/**
 * 搜索结果适配器（适配剧目/演员/剧团数据）
 */
public class SearchResultAdapter extends RecyclerView.Adapter<SearchResultAdapter.ResultViewHolder> {
    private Context mContext;
    private List<SearchItem> mResultList;

    public SearchResultAdapter(Context context, List<SearchItem> resultList) {
        this.mContext = context;
        this.mResultList = resultList;
    }

    @NonNull
    @Override
    public ResultViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext)
                .inflate(R.layout.item_search_result, parent, false);
        return new ResultViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ResultViewHolder holder, int position) {
        SearchItem item = mResultList.get(position);
        holder.ivCover.setImageResource(item.getCoverResId());
        holder.tvName.setText(item.getName());
        holder.tvSubtitle.setText(item.getSubtitle());

        // 点击搜索结果跳转到对应详情页
        holder.itemView.setOnClickListener(v -> {
            if (item.getType() == SearchItem.TYPE_DRAMA) {
                // 跳转到剧目详情页
                Intent intent = new Intent(mContext, DramaDetailActivity.class);

                intent.putExtra("drama_cover", item.getCoverResId());
                intent.putExtra("drama_name", item.getName());
                intent.putExtra("drama_time", item.getTime());
                intent.putExtra("drama_venue", item.getVenue());
                intent.putExtra("drama_type", item.getTypeStr());
                intent.putExtra("drama_ticket", item.getTicketStatus());
                intent.putExtra("drama_detail", item.getDetail());
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return mResultList == null ? 0 : mResultList.size();
    }

    public static class ResultViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCover;
        TextView tvName, tvSubtitle;

        public ResultViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCover = itemView.findViewById(R.id.iv_search_cover);
            tvName = itemView.findViewById(R.id.tv_search_name);
            tvSubtitle = itemView.findViewById(R.id.tv_search_subtitle);
        }
    }
}