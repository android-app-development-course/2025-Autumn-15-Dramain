package com.example.drama.bean;

/**
 * 推荐剧组的实体类
 */
public class GroupItem {
    private int coverResId;    // 剧组封面/头像资源ID
    private String groupName;  // 剧组名称
    private String desc;       // 剧组简介
    private String memberCount;// 成员数量

    // 构造方法
    public GroupItem(int coverResId, String groupName, String desc, String memberCount) {
        this.coverResId = coverResId;
        this.groupName = groupName;
        this.desc = desc;
        this.memberCount = memberCount;
    }

    // Getter方法（供适配器调用）
    public int getCoverResId() { return coverResId; }
    public String getGroupName() { return groupName; }
    public String getDesc() { return desc; }
    public String getMemberCount() { return memberCount; }
}