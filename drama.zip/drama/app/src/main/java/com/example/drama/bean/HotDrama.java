package com.example.drama.bean;

public class HotDrama {
    private int coverResId; // 封面图资源ID
    private String name;    // 剧目名
    private String company; // 剧团名

    public HotDrama(int coverResId, String name, String company) {
        this.coverResId = coverResId;
        this.name = name;
        this.company = company;
    }

    // Getter
    public int getCoverResId() { return coverResId; }
    public String getName() { return name; }
    public String getCompany() { return company; }
}