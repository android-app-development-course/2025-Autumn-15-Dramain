package com.example.drama.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.R;
import com.example.drama.RecommendDrama;
import com.example.drama.RecommendDramaAdapter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 猜你喜欢剧目详情页
 */
public class RecommendDramaDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommend_drama_detail);

        // 1. 接收从适配器传递的RecommendDrama数据
        int coverRes = getIntent().getIntExtra("recommend_cover", R.mipmap.ic_launcher);
        String name = getIntent().getStringExtra("recommend_name");
        String group = getIntent().getStringExtra("recommend_group");
        String tagsStr = getIntent().getStringExtra("recommend_tags");
        String desc = getIntent().getStringExtra("recommend_desc");

        // 2. 解析标签列表（还原逗号分隔的标签）
        String tagText = "";
        if (tagsStr != null && !tagsStr.isEmpty()) {
            tagText = String.join(" | ", Arrays.asList(tagsStr.split(",")));
        }

        // 3. 绑定数据到UI
        ((ImageView) findViewById(R.id.iv_recommend_cover)).setImageResource(coverRes);
        ((TextView) findViewById(R.id.tv_recommend_name)).setText(name);
        ((TextView) findViewById(R.id.tv_recommend_group)).setText(group);
        ((TextView) findViewById(R.id.tv_recommend_tags)).setText(tagText);
        ((TextView) findViewById(R.id.tv_recommend_desc)).setText(desc);

        RecyclerView rvMoreRecommend = findViewById(R.id.rv_more_recommend);
        rvMoreRecommend.setLayoutManager(new LinearLayoutManager(this));

        List<RecommendDrama> moreList = new ArrayList<>();
        // 推荐1：《天鹅湖》
        moreList.add(new RecommendDrama(
                R.mipmap.te, "天鹅湖", "中央芭蕾舞团",
                Arrays.asList("舞剧", "古典主义", "经典"),
                "柴可夫斯基经典作品，讲述公主被魔法变为天鹅，王子以真爱破除诅咒的故事。"
        ));
        // 推荐2：《胡桃夹子》
        moreList.add(new RecommendDrama(
                R.mipmap.al, "胡桃夹子", "马林斯基剧院芭蕾舞团",
                Arrays.asList("舞剧", "童话", "圣诞"),
                "以圣诞夜为背景，讲述小女孩克拉拉与胡桃夹子玩偶的奇幻冒险。"
        ));
        // 推荐3：《罗密欧与朱丽叶》
        moreList.add(new RecommendDrama(
                R.mipmap.al, "罗密欧与朱丽叶", "英国皇家芭蕾舞团",
                Arrays.asList("舞剧", "爱情", "悲剧"),
                "改编自莎士比亚名著，用舞蹈演绎经典爱情悲剧。"
        ));

        // 设置适配器（复用之前的RecommendDramaAdapter）
        rvMoreRecommend.setAdapter(new RecommendDramaAdapter(this, moreList));


        // 4. 返回按钮逻辑
        findViewById(R.id.iv_back).setOnClickListener(v -> finish());
    }
}