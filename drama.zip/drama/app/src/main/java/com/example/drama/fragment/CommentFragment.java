package com.example.drama.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.CommentAdapter;
import com.example.drama.CommentItem;
import com.example.drama.R;

import java.util.ArrayList;
import java.util.List;

public class CommentFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_comment, container, false);
        RecyclerView rvComment = rootView.findViewById(R.id.rv_comment);

        List<CommentItem> commentList = new ArrayList<>();
        commentList.add(new CommentItem(R.mipmap.zhao, "赵编剧", "@了你：你对《雷雨》结局的解读很独特", "11:23"));
        commentList.add(new CommentItem(R.mipmap.dh, "孙导演", "评论了你的文章：我认为现代改编需要保留...", "10:05"));
        commentList.add(new CommentItem(R.mipmap.jjjm, "吴戏剧迷", "@了你：下周的话剧演出一起去看吗？", "昨天"));

        rvComment.setLayoutManager(new LinearLayoutManager(getContext()));
        rvComment.setAdapter(new CommentAdapter(getContext(), commentList));
        return rootView;
    }
}