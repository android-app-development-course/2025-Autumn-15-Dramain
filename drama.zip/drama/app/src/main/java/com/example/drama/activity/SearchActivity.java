package com.example.drama.activity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.R;
import com.example.drama.SearchResultAdapter;
import com.example.drama.bean.SearchItem;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {
    private EditText etSearch;
    private ImageView ivClear;
    private RecyclerView rvResult;
    private SearchResultAdapter mAdapter;
    private List<SearchItem> mAllData; // 所有可搜索的原始数据
    private List<SearchItem> mFilteredData; // 筛选后的结果

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        // 初始化控件
        etSearch = findViewById(R.id.et_search);
        ivClear = findViewById(R.id.iv_clear);
        rvResult = findViewById(R.id.rv_search_result);

        // 初始化所有可搜索数据（模拟）
        initAllSearchData();

        // 初始化适配器
        mFilteredData = new ArrayList<>();
        mAdapter = new SearchResultAdapter(this, mFilteredData);
        rvResult.setLayoutManager(new LinearLayoutManager(this));
        rvResult.setAdapter(mAdapter);

        // 返回按钮逻辑
        findViewById(R.id.iv_back).setOnClickListener(v -> finish());

        // 搜索输入监听
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // 输入内容变化时，筛选数据
                filterSearchResult(s.toString());
                // 显示/隐藏清空按钮
                ivClear.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // 清空输入框
        ivClear.setOnClickListener(v -> etSearch.setText(""));
    }

    /**
     * 初始化所有可搜索的模拟数据
     */
    private void initAllSearchData() {
        mAllData = new ArrayList<>();
        // 剧目数据
        mAllData.add(new SearchItem(
                SearchItem.TYPE_DRAMA,
                R.mipmap.al,
                "暗恋桃花源",
                "赖声川剧团",
                "11月15日",
                "北京保利剧院",
                "话剧",
                "余票紧张",
                "《暗恋桃花源》是赖声川的经典话剧，讲述了“暗恋”与“桃花源”两个剧组因场地冲突同台演出的荒诞故事..."
        ));
        mAllData.add(new SearchItem(
                SearchItem.TYPE_DRAMA,
                R.mipmap.mzt,
                "摇滚莫扎特",
                "法扎剧团",
                "11月17日",
                "上海文化广场",
                "音乐剧",
                "少量余票",
                "《摇滚莫扎特》以摇滚曲风演绎莫扎特的一生，融合古典与现代音乐，舞台华丽..."
        ));
        mAllData.add(new SearchItem(
                SearchItem.TYPE_DRAMA,
                R.mipmap.te,
                "天鹅湖",
                "中央芭蕾舞团",
                "11月20日",
                "国家大剧院",
                "舞剧",
                "可售",
                "《天鹅湖》是柴可夫斯基创作的经典芭蕾舞剧，讲述公主被魔法变成天鹅的故事..."
        ));


    }

    /**
     * 根据关键词筛选搜索结果
     */
    private void filterSearchResult(String keyword) {
        mFilteredData.clear();
        if (keyword.isEmpty()) {
            mAdapter.notifyDataSetChanged();
            return;
        }

        // 遍历所有数据，匹配关键词（支持名称/副标题模糊匹配）
        for (SearchItem item : mAllData) {
            if (item.getName().contains(keyword) || item.getSubtitle().contains(keyword)) {
                mFilteredData.add(item);
            }
        }
        mAdapter.notifyDataSetChanged();
    }
}