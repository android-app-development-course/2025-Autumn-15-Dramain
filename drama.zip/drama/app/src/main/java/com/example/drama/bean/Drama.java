package com.example.drama.bean;

/**
 * 剧目实体类，对应SQLite中的剧目表字段
 */
public class Drama {
    // 剧目ID（主键）
    private int id;
    // 剧目名称
    private String name;
    // 剧目类型（音乐剧/话剧/戏曲等）
    private String type;
    // 演员/主创
    private String actor;
    // 演出时间
    private String time;

    // 无参构造（SQLite查询时需要）
    public Drama() {}

    // 有参构造（创建模拟数据时用）
    public Drama(int id, String name, String type, String actor, String time) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.actor = actor;
        this.time = time;
    }

    // Getter和Setter方法
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}