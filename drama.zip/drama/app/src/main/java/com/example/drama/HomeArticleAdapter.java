package com.example.drama;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.activity.ArticleDetailActivity;
import com.example.drama.bean.HomeArticle;

import java.util.List;

/**
 * 首页文章卡片的适配器
 */
public class HomeArticleAdapter extends RecyclerView.Adapter<HomeArticleAdapter.ArticleViewHolder> {

    private Context mContext;
    private List<HomeArticle> mArticleList;

    public HomeArticleAdapter(Context context, List<HomeArticle> articleList) {
        this.mContext = context;
        this.mArticleList = articleList;
    }

    @NonNull
    @Override
    public ArticleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.item_home_article, parent, false);
        return new ArticleViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ArticleViewHolder holder, int position) {
        HomeArticle article = mArticleList.get(position);
        // 修复：直接使用资源ID设置图片，不再解析字符串
        holder.tvTitle.setText(article.getTitle());
        holder.tvAuthor.setText(article.getAuthor());
        holder.tvLike.setText(String.valueOf(article.getLikeCount()));
        // 直接用资源ID设置封面和头像
        holder.ivCover.setImageResource(article.getCoverResId());
        holder.ivAvatar.setImageResource(article.getAvatarResId());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(mContext, ArticleDetailActivity.class);
            intent.putExtra("article_id", article.getId());
            intent.putExtra("article_title", article.getTitle());
            intent.putExtra("article_author", article.getAuthor());
            intent.putExtra("article_like", article.getLikeCount());
            intent.putExtra("article_cover", article.getCoverResId());
            intent.putExtra("article_content", article.getContent()); // 新增：传递文章内容
            mContext.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return mArticleList == null ? 0 : mArticleList.size();
    }

    // ViewHolder
    public static class ArticleViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAvatar, ivCover;
        TextView tvTitle, tvAuthor, tvLike;

        public ArticleViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.iv_avatar);
            ivCover = itemView.findViewById(R.id.iv_cover);
            tvTitle = itemView.findViewById(R.id.tv_title);
            tvAuthor = itemView.findViewById(R.id.tv_author);
            tvLike = itemView.findViewById(R.id.tv_like);
        }
    }
}