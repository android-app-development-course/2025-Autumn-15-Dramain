package com.example.drama;

public class MessageItem {
    private int avatarResId; // 头像资源ID
    private String title;    // 消息标题
    private String content;  // 消息内容
    private String time;     // 时间
    private int unreadCount; // 未读数量

    public MessageItem(int avatarResId, String title, String content, String time, int unreadCount) {
        this.avatarResId = avatarResId;
        this.title = title;
        this.content = content;
        this.time = time;
        this.unreadCount = unreadCount;
    }

    // Getter
    public int getAvatarResId() { return avatarResId; }
    public String getTitle() { return title; }
    public String getContent() { return content; }
    public String getTime() { return time; }
    public int getUnreadCount() { return unreadCount; }
}