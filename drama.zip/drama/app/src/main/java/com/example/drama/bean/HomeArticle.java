package com.example.drama.bean;

public class HomeArticle {
    private int id;             // 文章ID
    private int avatarResId;    // 作者头像资源ID
    private String title;       // 文章标题
    private String author;      // 作者名称
    private int likeCount;      // 点赞数
    private int coverResId;     // 文章封面图资源ID
    private String content;     // 新增：文章内容字段（核心）

    // 1. 新增含content的构造方法（推荐）
    public HomeArticle(int id, int avatarResId, String title, String author, int likeCount, int coverResId, String content) {
        this.id = id;
        this.avatarResId = avatarResId;
        this.title = title;
        this.author = author;
        this.likeCount = likeCount;
        this.coverResId = coverResId;
        this.content = content; // 初始化新增的内容字段
    }

    // 2. 保留原有构造方法（兼容旧数据）
    public HomeArticle(int id, int avatarResId, String title, String author, int likeCount, int coverResId) {
        this.id = id;
        this.avatarResId = avatarResId;
        this.title = title;
        this.author = author;
        this.likeCount = likeCount;
        this.coverResId = coverResId;
        this.content = ""; // 旧数据默认空内容
    }

    // 3. Getter/Setter方法（重点：新增content的get/set）
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getAvatarResId() { return avatarResId; }
    public void setAvatarResId(int avatarResId) { this.avatarResId = avatarResId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public int getLikeCount() { return likeCount; }
    public void setLikeCount(int likeCount) { this.likeCount = likeCount; }

    public int getCoverResId() { return coverResId; }
    public void setCoverResId(int coverResId) { this.coverResId = coverResId; }

    // 新增：content的Getter/Setter
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
}