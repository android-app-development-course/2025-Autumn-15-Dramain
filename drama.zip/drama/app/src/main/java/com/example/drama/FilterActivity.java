package com.example.drama;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class FilterActivity extends AppCompatActivity {
    private List<String> selectedFilters = new ArrayList<>();
    private TextView tvSelectedCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);

        // 初始化控件
        tvSelectedCount = findViewById(R.id.tv_selected_count);
        TextView tvReset = findViewById(R.id.tv_reset);
        Button btnConfirm = findViewById(R.id.btn_confirm);
        ImageView ivBack = findViewById(R.id.iv_back);

        // ========== 1. 剧种标签 ==========
        findViewById(R.id.tv_type_musical).setOnClickListener(v -> toggleFilter((TextView) v, "音乐剧"));
        findViewById(R.id.tv_type_drama).setOnClickListener(v -> toggleFilter((TextView) v, "话剧"));
        findViewById(R.id.tv_type_dance).setOnClickListener(v -> toggleFilter((TextView) v, "舞剧"));
        findViewById(R.id.tv_type_opera).setOnClickListener(v -> toggleFilter((TextView) v, "歌剧"));
        findViewById(R.id.tv_type_children).setOnClickListener(v -> toggleFilter((TextView) v, "儿童剧"));
        findViewById(R.id.tv_type_other).setOnClickListener(v -> toggleFilter((TextView) v, "剧种_其他"));

        // ========== 2. 演出语种标签 ==========
        findViewById(R.id.tv_lang_cn).setOnClickListener(v -> toggleFilter((TextView) v, "中文"));
        findViewById(R.id.tv_lang_en).setOnClickListener(v -> toggleFilter((TextView) v, "英语"));
        findViewById(R.id.tv_lang_fr).setOnClickListener(v -> toggleFilter((TextView) v, "法语"));
        findViewById(R.id.tv_lang_de).setOnClickListener(v -> toggleFilter((TextView) v, "德语"));
        findViewById(R.id.tv_lang_ja).setOnClickListener(v -> toggleFilter((TextView) v, "日语"));
        findViewById(R.id.tv_lang_cantonese).setOnClickListener(v -> toggleFilter((TextView) v, "粤语"));
        findViewById(R.id.tv_lang_other).setOnClickListener(v -> toggleFilter((TextView) v, "语种_其他"));

        // ========== 3. 出品地区标签 ==========
        findViewById(R.id.tv_region_cn).setOnClickListener(v -> toggleFilter((TextView) v, "中国大陆"));
        findViewById(R.id.tv_region_hk).setOnClickListener(v -> toggleFilter((TextView) v, "香港"));
        findViewById(R.id.tv_region_tw).setOnClickListener(v -> toggleFilter((TextView) v, "台湾"));
        findViewById(R.id.tv_region_us).setOnClickListener(v -> toggleFilter((TextView) v, "美国"));
        findViewById(R.id.tv_region_uk).setOnClickListener(v -> toggleFilter((TextView) v, "英国"));
        findViewById(R.id.tv_region_fr).setOnClickListener(v -> toggleFilter((TextView) v, "法国"));
        findViewById(R.id.tv_region_de).setOnClickListener(v -> toggleFilter((TextView) v, "德国"));
        findViewById(R.id.tv_region_kr).setOnClickListener(v -> toggleFilter((TextView) v, "韩国"));
        findViewById(R.id.tv_region_jp).setOnClickListener(v -> toggleFilter((TextView) v, "日本"));
        findViewById(R.id.tv_region_other).setOnClickListener(v -> toggleFilter((TextView) v, "地区_其他"));

        // ========== 4. 悲喜剧类型标签 ==========
        findViewById(R.id.tv_style_tragedy).setOnClickListener(v -> toggleFilter((TextView) v, "悲剧"));
        findViewById(R.id.tv_style_comedy).setOnClickListener(v -> toggleFilter((TextView) v, "喜剧"));
        findViewById(R.id.tv_style_tragicomedy).setOnClickListener(v -> toggleFilter((TextView) v, "悲喜剧"));
        findViewById(R.id.tv_style_farce).setOnClickListener(v -> toggleFilter((TextView) v, "闹剧"));

        // ========== 5. 演出年份标签 ==========
        findViewById(R.id.tv_year_2000).setOnClickListener(v -> toggleFilter((TextView) v, "2000"));
        findViewById(R.id.tv_year_2001).setOnClickListener(v -> toggleFilter((TextView) v, "2001"));
        findViewById(R.id.tv_year_2002).setOnClickListener(v -> toggleFilter((TextView) v, "2002"));

        // 返回按钮
        ivBack.setOnClickListener(v -> finish());

        // 重置按钮
        tvReset.setOnClickListener(v -> resetFilters());

        // 应用筛选按钮
        btnConfirm.setOnClickListener(v -> {
            // 此处可将selectedFilters传递给剧目库页面，进行数据筛选
            finish();
        });
    }

    // 切换标签选中状态
    private void toggleFilter(TextView tv, String filterName) {
        if (selectedFilters.contains(filterName)) {
            // 取消选中
            selectedFilters.remove(filterName);
            tv.setBackgroundColor(getResources().getColor(R.color.gray_light));
            tv.setTextColor(getResources().getColor(R.color.black));
        } else {
            // 选中
            selectedFilters.add(filterName);
            tv.setBackgroundColor(getResources().getColor(R.color.teal_dark));
            tv.setTextColor(getResources().getColor(R.color.white));
        }
        // 更新已选数量
        tvSelectedCount.setText("已选择 " + selectedFilters.size() + " 个筛选条件");
    }

    // 重置所有筛选条件
    private void resetFilters() {
        selectedFilters.clear();
        // 重置所有标签样式（示例：剧种标签）
        resetTagStyle(R.id.tv_type_musical);
        resetTagStyle(R.id.tv_type_drama);
        // ... 其他标签需逐个调用resetTagStyle
        tvSelectedCount.setText("已选择 0 个筛选条件");
    }

    // 重置单个标签样式
    private void resetTagStyle(int viewId) {
        TextView tv = findViewById(viewId);
        tv.setBackgroundColor(getResources().getColor(R.color.gray_light));
        tv.setTextColor(getResources().getColor(R.color.black));
    }
}