package com.example.drama.bean;

public class RecentDrama {
    private int coverResId;     // 剧目封面图
    private String name;        // 剧目名称
    private String time;        // 演出时间
    private String venue;       // 演出场馆
    private String type;        // 剧目类型
    private String ticketStatus;// 票务状态（字段名是ticketStatus）
    private String detail;      // 剧目详情

    // 构造方法（匹配你的初始化代码）
    public RecentDrama(int coverResId, String name, String time, String venue, String type, String ticketStatus) {
        this.coverResId = coverResId;
        this.name = name;
        this.time = time;
        this.venue = venue;
        this.type = type;
        this.ticketStatus = ticketStatus;
        this.detail = "";
    }

    public RecentDrama(int coverResId, String name, String time, String venue, String type, String ticketStatus, String detail) {
        this.coverResId = coverResId;
        this.name = name;
        this.time = time;
        this.venue = venue;
        this.type = type;
        this.ticketStatus = ticketStatus;
        this.detail = "";
    }

    // 正确的Getter方法（重点：是getTicketStatus，不是getStatus）
    public int getCoverResId() { return coverResId; }
    public String getName() { return name; }
    public String getTime() { return time; }
    public String getVenue() { return venue; }
    public String getType() { return type; }
    public String getTicketStatus() { return ticketStatus; } // 正确方法名
    public String getDetail() { return detail; }

    public void setDetail(String detail) { this.detail = detail; }

    public void setCoverResId(int coverResId) {
        this.coverResId = coverResId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setTicketStatus(String ticketStatus) {
        this.ticketStatus = ticketStatus;
    }
}