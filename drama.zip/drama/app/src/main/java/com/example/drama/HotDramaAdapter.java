package com.example.drama;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.bean.HotDrama;

import java.util.List;

public class HotDramaAdapter extends RecyclerView.Adapter<HotDramaAdapter.HotViewHolder> {
    private List<HotDrama> hotDramaList;

    public HotDramaAdapter(List<HotDrama> hotDramaList) {
        this.hotDramaList = hotDramaList;
    }

    @NonNull
    @Override
    public HotViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_hot_drama, parent, false);
        return new HotViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HotViewHolder holder, int position) {
        HotDrama drama = hotDramaList.get(position);
        holder.ivCover.setImageResource(drama.getCoverResId());
        holder.tvName.setText(drama.getName());
        holder.tvCompany.setText(drama.getCompany());
    }

    @Override
    public int getItemCount() {
        return hotDramaList.size();
    }

    public static class HotViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCover;
        TextView tvName, tvCompany;

        public HotViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCover = itemView.findViewById(R.id.iv_hot_cover);
            tvName = itemView.findViewById(R.id.tv_hot_name);
            tvCompany = itemView.findViewById(R.id.tv_hot_company);
        }
    }
}