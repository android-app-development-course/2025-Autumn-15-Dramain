package com.example.drama;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.bean.GroupItem;

import java.util.List;

/**
 * 推荐剧组列表的适配器
 */
public class GroupAdapter extends RecyclerView.Adapter<GroupAdapter.GroupViewHolder> {
    private Context mContext;
    private List<GroupItem> mGroupList;

    // 构造方法
    public GroupAdapter(Context context, List<GroupItem> groupList) {
        this.mContext = context;
        this.mGroupList = groupList;
    }

    @NonNull
    @Override
    public GroupViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 加载剧组列表项布局
        View view = LayoutInflater.from(mContext)
                .inflate(R.layout.item_group, parent, false);
        return new GroupViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GroupViewHolder holder, int position) {
        // 绑定数据到控件
        GroupItem item = mGroupList.get(position);
        holder.ivCover.setImageResource(item.getCoverResId());
        holder.tvGroupName.setText(item.getGroupName());
        holder.tvDesc.setText(item.getDesc());
        holder.tvMemberCount.setText(item.getMemberCount());

        // 可选：添加剧组条目点击事件
        holder.itemView.setOnClickListener(v -> {
            // 点击剧组后的逻辑（如进入剧组详情页）
        });
    }

    @Override
    public int getItemCount() {
        return mGroupList == null ? 0 : mGroupList.size();
    }

    // ViewHolder：缓存列表项控件
    public static class GroupViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCover;
        TextView tvGroupName, tvDesc, tvMemberCount;

        public GroupViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCover = itemView.findViewById(R.id.iv_group_cover);
            tvGroupName = itemView.findViewById(R.id.tv_group_name);
            tvDesc = itemView.findViewById(R.id.tv_group_desc);
            tvMemberCount = itemView.findViewById(R.id.tv_group_member);
        }
    }
}