package com.example.drama.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

import com.example.drama.R;

public class CreateFragment extends Fragment {

    private EditText etTitle, etContent;
    private Button btnSave, btnPublish;

    public CreateFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_create, container, false);
        
        // 初始化控件
        etTitle = rootView.findViewById(R.id.et_create_title);
        etContent = rootView.findViewById(R.id.et_create_content);
        btnSave = rootView.findViewById(R.id.btn_save_draft);
        btnPublish = rootView.findViewById(R.id.btn_publish);
        
        // 保存草稿（后续对接SQLite）
        btnSave.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String content = etContent.getText().toString().trim();
            if (title.isEmpty()) {
                Toast.makeText(getContext(), "请输入标题", Toast.LENGTH_SHORT).show();
                return;
            }
            // 后续实现：将草稿存入SQLite
            Toast.makeText(getContext(), "草稿保存成功", Toast.LENGTH_SHORT).show();
        });
        
        // 发布内容
        btnPublish.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String content = etContent.getText().toString().trim();
            if (title.isEmpty() || content.isEmpty()) {
                Toast.makeText(getContext(), "标题和内容不能为空", Toast.LENGTH_SHORT).show();
                return;
            }
            // 后续实现：发布逻辑（存入SQLite+更新列表）
            Toast.makeText(getContext(), "发布成功", Toast.LENGTH_SHORT).show();
            // 清空输入框
            etTitle.setText("");
            etContent.setText("");
        });
        
        return rootView;
    }
}