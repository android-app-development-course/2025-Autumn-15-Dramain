package com.example.drama;

import java.util.List;

public class RecommendDrama {
    private int coverResId; // 封面图资源ID
    private String name;    // 剧目名
    private String company; // 剧团名
    private List<String> tags; // 标签（如“话剧”“经典”）
    private String desc;    // 剧目简介

    public RecommendDrama(int coverResId, String name, String company, List<String> tags, String desc) {
        this.coverResId = coverResId;
        this.name = name;
        this.company = company;
        this.tags = tags;
        this.desc = desc;
    }

    // Getter
    public int getCoverResId() { return coverResId; }
    public String getName() { return name; }
    public String getCompany() { return company; }
    public List<String> getTags() { return tags; }
    public String getDesc() { return desc; }
}