package com.example.drama;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.activity.DramaDetailActivity;
import com.example.drama.bean.RecentDrama;

import java.util.List;

public class RecentDramaAdapter extends RecyclerView.Adapter<RecentDramaAdapter.RecentViewHolder> {
    private List<RecentDrama> recentDramaList;
    private Context mContext;

    public RecentDramaAdapter( Context context,List<RecentDrama> recentDramaList) {
        this.mContext = context;
        this.recentDramaList = recentDramaList;
    }

    @NonNull
    @Override
    public RecentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_recent_drama, parent, false);
        return new RecentViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecentViewHolder holder, int position) {
        RecentDrama drama = recentDramaList.get(position);
        holder.ivCover.setImageResource(drama.getCoverResId());
        holder.tvName.setText(drama.getName());
        holder.tvVenueTime.setText(drama.getVenue() + " · " + drama.getTime());
        holder.tvType.setText(drama.getType());
        holder.tvStatus.setText(drama.getTicketStatus());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(mContext, DramaDetailActivity.class);
            // 传递RecentDrama的所有字段到详情页
            intent.putExtra("drama_cover", drama.getCoverResId());
            intent.putExtra("drama_name", drama.getName());
            intent.putExtra("drama_time", drama.getTime());
            intent.putExtra("drama_venue", drama.getVenue());
            intent.putExtra("drama_type", drama.getType());
            intent.putExtra("drama_ticket", drama.getTicketStatus());
            intent.putExtra("drama_detail", drama.getDetail());
            mContext.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return recentDramaList.size();
    }

    public static class RecentViewHolder extends RecyclerView.ViewHolder {
        ImageView ivCover;
        TextView tvName, tvVenueTime, tvType, tvStatus;

        public RecentViewHolder(@NonNull View itemView) {
            super(itemView);
            ivCover = itemView.findViewById(R.id.iv_drama_cover);
            tvName = itemView.findViewById(R.id.tv_drama_name);
            tvVenueTime = itemView.findViewById(R.id.tv_drama_venue_time);
            tvType = itemView.findViewById(R.id.tv_drama_type);
            tvStatus = itemView.findViewById(R.id.tv_drama_ticket);
        }
    }
}