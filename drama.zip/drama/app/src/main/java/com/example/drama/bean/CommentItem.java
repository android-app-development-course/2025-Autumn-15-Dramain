package com.example.drama.bean;

/**
 * 评论实体类：新增articleId字段，区分不同文章的评论
 */
public class CommentItem {
    private int articleId;     // 关联的文章ID（核心：区分不同文章的评论）
    private int avatarResId;   // 评论者头像
    private String userName;   // 评论者昵称
    private String content;    // 评论内容
    private String time;       // 评论时间

    // 构造方法（新增articleId）
    public CommentItem(int articleId, int avatarResId, String userName, String content, String time) {
        this.articleId = articleId;
        this.avatarResId = avatarResId;
        this.userName = userName;
        this.content = content;
        this.time = time;
    }

    // Getter方法
    public int getArticleId() { return articleId; }
    public int getAvatarResId() { return avatarResId; }
    public String getUserName() { return userName; }
    public String getContent() { return content; }
    public String getTime() { return time; }
}