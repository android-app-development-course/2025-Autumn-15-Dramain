package com.example.drama;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.bean.FanItem;

import java.util.List;

/**
 * 新增粉丝列表的适配器
 */
public class FanAdapter extends RecyclerView.Adapter<FanAdapter.FanViewHolder> {
    private Context mContext;
    private List<FanItem> mFanList;

    // 构造方法
    public FanAdapter(Context context, List<FanItem> fanList) {
        this.mContext = context;
        this.mFanList = fanList;
    }

    @NonNull
    @Override
    public FanViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 加载新增粉丝列表项布局
        View view = LayoutInflater.from(mContext)
                .inflate(R.layout.item_fan, parent, false);
        return new FanViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FanViewHolder holder, int position) {
        // 绑定数据到控件
        FanItem item = mFanList.get(position);
        holder.ivAvatar.setImageResource(item.getAvatarResId());
        holder.tvUserName.setText(item.getUserName());
        holder.tvDesc.setText(item.getDesc());
        holder.tvTime.setText(item.getTime());
    }

    @Override
    public int getItemCount() {
        return mFanList == null ? 0 : mFanList.size();
    }

    // ViewHolder：缓存列表项控件
    public static class FanViewHolder extends RecyclerView.ViewHolder {
        ImageView ivAvatar;
        TextView tvUserName, tvDesc, tvTime;

        public FanViewHolder(@NonNull View itemView) {
            super(itemView);
            ivAvatar = itemView.findViewById(R.id.iv_fan_avatar);
            tvUserName = itemView.findViewById(R.id.tv_fan_name);
            tvDesc = itemView.findViewById(R.id.tv_fan_desc);
            tvTime = itemView.findViewById(R.id.tv_fan_time);
        }
    }
}