package com.example.drama.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.drama.FanAdapter;
import com.example.drama.bean.FanItem;
import com.example.drama.R;

import java.util.ArrayList;
import java.util.List;

public class NewFanFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_new_fan, container, false);
        RecyclerView rvNewFan = rootView.findViewById(R.id.rv_new_fan);

        List<FanItem> fanList = new ArrayList<>();
        fanList.add(new FanItem(R.mipmap.yy, "陈演员", "关注了你，他是国家话剧院演员", "今天 08:30"));
        fanList.add(new FanItem(R.mipmap.xjj, "刘戏剧爱好者", "关注了你，他喜欢曹禺作品", "昨天 19:45"));

        rvNewFan.setLayoutManager(new LinearLayoutManager(getContext()));
        rvNewFan.setAdapter(new FanAdapter(getContext(), fanList));
        return rootView;
    }
}