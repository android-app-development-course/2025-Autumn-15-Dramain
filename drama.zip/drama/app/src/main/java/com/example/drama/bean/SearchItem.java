package com.example.drama.bean;

/**
 * 搜索结果实体类（新增剧目关联字段）
 */
public class SearchItem {
    public static final int TYPE_DRAMA = 1;   // 剧目类型
    public static final int TYPE_ACTOR = 2;   // 演员类型
    public static final int TYPE_GROUP = 3;   // 剧团类型

    // 基础字段
    private int type;           // 搜索结果类型
    private int coverResId;     // 封面图
    private String name;        // 剧目名/演员名/剧团名
    private String subtitle;    // 副标题（演出场馆/演员代表作）
    
    // 剧目专属字段（适配DramaDetailActivity）
    private String time;        // 演出时间
    private String venue;       // 演出场馆
    private String typeStr;     // 剧目类型（话剧/音乐剧）
    private String ticketStatus;// 票务状态
    private String detail;      // 剧目详情

    // 构造方法（适配剧目类型）
    public SearchItem(int type, int coverResId, String name, String subtitle, 
                      String time, String venue, String typeStr, String ticketStatus, String detail) {
        this.type = type;
        this.coverResId = coverResId;
        this.name = name;
        this.subtitle = subtitle;
        this.time = time;
        this.venue = venue;
        this.typeStr = typeStr;
        this.ticketStatus = ticketStatus;
        this.detail = detail;
    }

    // 原有构造方法（兼容其他类型）
    public SearchItem(int type, int coverResId, String name, String subtitle) {
        this.type = type;
        this.coverResId = coverResId;
        this.name = name;
        this.subtitle = subtitle;
    }

    // Getter方法（所有字段）
    public int getType() { return type; }
    public int getCoverResId() { return coverResId; }
    public String getName() { return name; }
    public String getSubtitle() { return subtitle; }
    public String getTime() { return time; }
    public String getVenue() { return venue; }
    public String getTypeStr() { return typeStr; }
    public String getTicketStatus() { return ticketStatus; }
    public String getDetail() { return detail; }
}